from . import train

def constructor(self, meta, FLAGS):
	self.meta, self.FLAGS = meta, FLAGS